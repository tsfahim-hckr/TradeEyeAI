package com.elitera.tradeeye

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val REQ = 100
    private lateinit var keyInput: EditText
    private lateinit var secInput: EditText
    private lateinit var confInput: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun field(hint: String, value: String) = EditText(this).apply {
        setHint(hint)
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#16213A"))
        }
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun btn(label: String, color: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor(color))
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) }
        setOnClickListener { action() }
    }

    private fun label(t: String, size: Float, color: String, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor(color))
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B1220")
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
        }
        root.addView(logo)
        root.addView(label("TradeEye AI", 28f, "#FFFFFF", true))
        root.addView(label("Screen scan + voice signal", 14f, "#94A3B8"))

        keyInput = field("Anthropic API key (sk-ant-...)", prefs.getString("key", "") ?: "")
        keyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        secInput = field("Scan interval (sec, 2-60)", prefs.getString("sec", "4") ?: "4")
        secInput.inputType = InputType.TYPE_CLASS_NUMBER
        confInput = field("Min confidence % (signal er jonno)", prefs.getString("conf", "65") ?: "65")
        confInput.inputType = InputType.TYPE_CLASS_NUMBER
        root.addView(keyInput)
        root.addView(secInput)
        root.addView(confInput)

        root.addView(btn("START SCAN", "#16A34A") { startScan() })
        root.addView(btn("STOP", "#DC2626") {
            stopService(Intent(this, ScanService::class.java))
            Toast.makeText(this, "Scan bondho", Toast.LENGTH_SHORT).show()
        })
        root.addView(label("Age demo account e test koro. AI er signal 100% sothik na, loss hote pare.", 12f, "#F59E0B"))
        root.addView(label("Powered by Elitera • Developed by Fahim Hasan", 11f, "#64748B"))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1220"))
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startScan() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "API key dao", Toast.LENGTH_SHORT).show()
            return
        }
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("key", key)
            .putString("sec", secInput.text.toString().ifBlank { "4" })
            .putString("conf", confInput.text.toString().ifBlank { "65" })
            .apply()

        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Overlay permission on kore abar START dao", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScanService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Scan shuru! Ekhon trading site/app e jao", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
