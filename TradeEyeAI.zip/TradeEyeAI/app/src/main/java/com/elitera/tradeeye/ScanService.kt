package com.elitera.tradeeye

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class ScanService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null

    @Volatile private var busy = false
    private var running = false
    private var lastSignal = ""
    private var intervalMs = 4000L
    private var minConf = 65
    private var apiKey = ""
    private var provider = "gemini"

    private val systemPrompt = """
You are a cautious technical-analysis assistant. The image is a phone screenshot, usually of a trading chart.
Ignore any small floating box titled "TradeEye AI".
If there is no readable price chart, answer NO_CHART.
Otherwise identify the pair, timeframe, trend, candle patterns, support/resistance and visible indicators (RSI, MACD, EMA etc).
Decide BUY (price likely up), SELL (price likely down) or WAIT.
Give BUY or SELL only when the evidence is clear; otherwise WAIT.
"seconds" = suggested trade duration in seconds, sensible for the visible timeframe (for a 1m chart: 30-120).
Reply with ONLY this JSON and nothing else:
{"signal":"BUY|SELL|WAIT|NO_CHART","confidence":0-100,"seconds":30,"reason":"max 12 words"}
""".trimIndent()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running || intent == null) return START_NOT_STICKY
        running = true

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        provider = prefs.getString("provider", "gemini") ?: "gemini"
        apiKey = prefs.getString("key_$provider", "") ?: ""
        intervalMs = (prefs.getString("sec", "4")?.toLongOrNull() ?: 4L).coerceIn(2L, 60L) * 1000L
        minConf = prefs.getString("conf", "65")?.toIntOrNull() ?: 65

        startAsForeground()

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                ttsReady = true
                speak("Trade eye started")
            }
        }
        showOverlay()
        setupCapture()
        main.postDelayed(tick, 2000)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("scan", "TradeEye scan", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "scan")
            .setContentTitle("TradeEye AI")
            .setContentText("Screen scan cholche")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupCapture() {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = projection?.createVirtualDisplay(
            "tradeeye", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, main
        )
    }

    private val tick = object : Runnable {
        override fun run() {
            try {
                capture()
            } catch (e: Exception) {
                show("ERROR", e.message ?: "error", "#6B7280")
            }
            main.postDelayed(this, intervalMs)
        }
    }

    private fun capture() {
        if (busy) return
        val img = reader?.acquireLatestImage() ?: return
        val b64 = try {
            val p = img.planes[0]
            val bw = p.rowStride / p.pixelStride
            val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(p.buffer)
            val crop = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
            val tw = 1000
            val th = (crop.height * (tw.toFloat() / crop.width)).toInt()
            val small = Bitmap.createScaledBitmap(crop, tw, th, true)
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 70, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } finally {
            img.close()
        }
        busy = true
        Thread {
            try {
                val res = callApi(b64)
                main.post { handle(res) }
            } catch (e: Exception) {
                main.post { show("ERROR", (e.message ?: "network error").take(80), "#6B7280") }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun callApi(b64: String): JSONObject {
        val url: String
        val body: JSONObject
        val headers = mutableMapOf("content-type" to "application/json")
        when (provider) {
            "openai" -> {
                url = "https://api.openai.com/v1/chat/completions"
                headers["Authorization"] = "Bearer $apiKey"
                val userContent = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", "Analyze this screen now."))
                    .put(
                        JSONObject().put("type", "image_url").put(
                            "image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")
                        )
                    )
                body = JSONObject()
                    .put("model", "gpt-4o-mini")
                    .put("max_tokens", 300)
                    .put(
                        "messages", JSONArray()
                            .put(JSONObject().put("role", "system").put("content", systemPrompt))
                            .put(JSONObject().put("role", "user").put("content", userContent))
                    )
            }
            "claude" -> {
                url = "https://api.anthropic.com/v1/messages"
                headers["x-api-key"] = apiKey
                headers["anthropic-version"] = "2023-06-01"
                val source = JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
                val content = JSONArray()
                    .put(JSONObject().put("type", "image").put("source", source))
                    .put(JSONObject().put("type", "text").put("text", "Analyze this screen now."))
                body = JSONObject()
                    .put("model", "claude-sonnet-5-5")
                    .put("max_tokens", 300)
                    .put("system", systemPrompt)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
            }
            else -> {
                url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$apiKey"
                val parts = JSONArray()
                    .put(JSONObject().put("text", "Analyze this screen now."))
                    .put(
                        JSONObject().put(
                            "inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)
                        )
                    )
                body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 1000))
            }
        }

        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("API $code: " + txt.take(100))

        val t = when (provider) {
            "openai" -> JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            "claude" -> JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
            else -> JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
        val s = t.indexOf('{')
        val e = t.lastIndexOf('}')
        return JSONObject(t.substring(s, e + 1))
    }

    private fun handle(r: JSONObject) {
        var sig = r.optString("signal", "WAIT").uppercase()
        val conf = r.optInt("confidence", 0)
        val sec = r.optInt("seconds", 30)
        val why = r.optString("reason", "")
        if ((sig == "BUY" || sig == "SELL") && conf < minConf) sig = "WAIT"

        val changed = sig != lastSignal
        when (sig) {
            "BUY" -> {
                show("BUY ▲  ${sec}s", "$conf% • $why", "#16A34A")
                if (changed) speak("Buy. $sec seconds.")
            }
            "SELL" -> {
                show("SELL ▼  ${sec}s", "$conf% • $why", "#DC2626")
                if (changed) speak("Sell. $sec seconds.")
            }
            "NO_CHART" -> {
                show("NO CHART", "Chart dekha jacche na", "#475569")
                if (changed) speak("Chart not visible.")
            }
            else -> {
                show("WAIT", why, "#B45309")
                if (changed) speak("Wait.")
            }
        }
        lastSignal = sig
    }

    private fun show(title: String, sub: String, color: String) {
        overlay?.apply {
            text = "$title\n$sub"
            background = GradientDrawable().apply {
                cornerRadius = 28f
                setColor(Color.parseColor(color))
            }
        }
    }

    private fun speak(t: String) {
        if (ttsReady) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "tradeeye")
    }

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val tv = TextView(this).apply {
            text = "TradeEye AI\nscanning..."
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(28, 18, 28, 18)
            maxWidth = 640
            background = GradientDrawable().apply {
                cornerRadius = 28f
                setColor(Color.parseColor("#CC0B1220"))
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 160
        }
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(tv, lp)
                }
            }
            true
        }
        wm.addView(tv, lp)
        overlay = tv
    }

    override fun onDestroy() {
        main.removeCallbacks(tick)
        display?.release()
        reader?.close()
        projection?.stop()
        tts?.shutdown()
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
