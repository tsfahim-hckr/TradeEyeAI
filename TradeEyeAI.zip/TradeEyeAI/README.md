# TradeEye AI
Screen scan + voice trading signal app (Android).
Powered by Elitera • Developed by Fahim Hasan

## GitHub theke APK banano
1. GitHub e notun repository banao, ei folder er shob file upload/push koro (.github folder shoho).
2. Repo er **Actions** tab e jao -> "Build APK" workflow cholbe (na cholle "Run workflow" chapo).
3. Shesh hole oi run e dhukle **Artifacts -> TradeEye-AI-APK** pabe. Download kore phone e install koro.

## Use
1. App kholo, AI select koro (Gemini free: aistudio.google.com / ChatGPT: platform.openai.com / Claude: console.anthropic.com), tar API key dao.
2. START SCAN -> Overlay permission on koro -> Screen capture allow koro.
3. Trading site/app e jao. Floating box e signal ashbe, voice e bolbe.

Note: Age demo account e test koro. Signal 100% sothik na.
